import { Component, Input, OnInit } from '@angular/core';
import { Users } from '../models/users';
import { UsersService } from '../services/users.service';
import { faCheck } from '@fortawesome/free-solid-svg-icons';
import { faX } from '@fortawesome/free-solid-svg-icons';
import { faMagnifyingGlass } from '@fortawesome/free-solid-svg-icons';
import { faToggleOff } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss'],
})
export class UsersComponent implements OnInit {
  users: Users[] = [];
  title: any;
  p: number = 1;
  faCheck = faCheck;
  faX = faX;
  faSearch = faMagnifyingGlass;
  faTog = faToggleOff;
  x: boolean = false;
  check: boolean = false;
  constructor(private srv: UsersService) {}
  @Input('user-data') user!: Users;

  ngOnInit(): void {
    this.srv.fetchUsers().subscribe((ris) => {
      this.users = ris;
      console.log(this.users);
      if (this.user.completed === 'false') {
        //this.x = true;
      } else{
        //this.check = true;
      }
    });
  }

  Search() {
    if (this.title == '') {
      this.ngOnInit();
    } else {
      this.users = this.users.filter((res) => {
        return res.title
          .toLocaleLowerCase()
          .match(this.title.toLocaleLowerCase());
      });
    }
  }
}
