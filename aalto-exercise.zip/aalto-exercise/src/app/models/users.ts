export interface Users {
  user_id:number,
  id: number,
  title: string,
  completed: string

}
